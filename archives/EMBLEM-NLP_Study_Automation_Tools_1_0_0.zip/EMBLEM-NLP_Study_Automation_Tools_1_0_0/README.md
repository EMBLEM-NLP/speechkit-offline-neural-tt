# EMBLEM-NLP Study Automation Tools 1.0.0

This wrapper contains the unchanged three reusable video plugins (1.0.1) plus the new OBC Study Orchestrator sidecar (1.0.0). Read the sidecar README and execution report. The voice runtime and complete source PDFs/SQLite remain separate pinned inputs. Do not register old and new copies of the same three plugins together. No persistent hosted render runner is deployed by extracting this package.
