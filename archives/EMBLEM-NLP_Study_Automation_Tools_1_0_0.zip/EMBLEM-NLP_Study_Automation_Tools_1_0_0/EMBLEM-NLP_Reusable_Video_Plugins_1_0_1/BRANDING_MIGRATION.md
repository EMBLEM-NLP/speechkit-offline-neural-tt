# EMBLEM-NLP branding correction — 1.0.1

This distribution corrects the product brand to **EMBLEM-NLP**. It is a branding/packaging patch, not a changed renderer, speech model or scoring contract.

| Component | Current canonical directory / plugin ID | Current private package name |
|---|---|---|
| Video Factory | `emblem-nlp-video-factory` | `@emblem-nlp/video-factory` |
| Neural Narration | `emblem-nlp-neural-narration` | `@emblem-nlp/neural-narration` |
| Video RSI Adapter | `emblem-nlp-video-rsi` | `@emblem-nlp/video-rsi` |

## Existing installations
Replace the three old plugin directories and update host/MCP paths to the new canonical directories. Re-register rather than loading old and new registrations together. The MCP server key is `emblem-nlp-video`. Tool names, CLI verbs, project schemaVersion 1.0.0, scene apiVersion 1.0.0, and speech schemaVersion 1.0.0 remain unchanged. Existing project JSON needs no schema conversion. An explicitly supplied project brand stays the author's choice; the bundled branded example now uses EMBLEM-NLP.

Use `EMBLEM_NLP_PYTHON` for the Python executable. Legacy `EMBLEM_PYTHON` remains a supported fallback; explicit CLI/API Python selection takes precedence over both. The sibling neural-provider lookup now resolves the new directory name. The shipped JavaScript and TypeScript source agree.

## Intentionally immutable material
The legacy RSI ZIP and its lock, technical-rubric bytes and historical series ID, schema URN `urn:emblem:video:project:1.0.0`, source PDF, voice model/profile and third-party notices are preserved. They are compatibility/provenance identities, not current display branding. Historical validation records in `history/v1.0.0/` retain their original text and are not evidence of a new test run.

The offline runtime is also byte-identical: only its downloadable filename is corrected to `EMBLEM-NLP_Offline_Neural_Runtime_Linux_Py313.zip`. The pinned SHA-256 is unchanged and existing copies remain usable when passed with `--archive`. Internal dependency/license/provenance filenames are not rewritten.

## Media scope
Existing course/demo MP4s are not overwritten or re-exported by this naming correction. New renders using the corrected branded example display EMBLEM-NLP. This patch does not claim a fresh naturalness, communication or learning score.
