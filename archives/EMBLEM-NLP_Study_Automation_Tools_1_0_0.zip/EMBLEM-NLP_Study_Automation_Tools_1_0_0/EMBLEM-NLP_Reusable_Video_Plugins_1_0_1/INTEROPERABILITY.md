# Versioned contracts and adapters

```text
new-project/project.json + source assets + theme
                 |
                 +--> validate / plan (compiled TypeScript)
                 |
 narration text --> neural plugin --> speech.json + per-scene PCM WAV
                 |                       |
                 +-------- prepare <-----+ (or supplied hashed WAVs)
                              |
       registry plugin API 1.0.0 --> SVG states --> RGB PNG --> CFR picture
                              |                             |
                   measured PCM + native CC + chapters ------+--> MP4
                                                                   |
                          render-manifest.json --> RSI adapter --> diagnostics
                                                            +--> actual-time dual review
                                                            +--> separate human acceptance
```

## Project manifest

`schemaVersion: 1.0.0`; no fixed number of questions. Assets carry id, relative path, exact SHA-256, kind (`pdf`/`image`), provenance, source label, physical PDF page and optional normalized crop. Tables have exact headers/rows/notes and an explicit `reading` versus `matched` selection mode. A matched result requires a stated evidence reason; the software does not certify that reason's truth.

## Scene plugin interface

```ts
interface Plugin {
  id: string;
  version: string;
  apiVersion: '1.0.0';
  validate(scene: Scene): void;
  render(context: Context): { svg: string; text: TextPlacement[] };
}
```

`Context` includes explicit time/progress, canvas, content boundary, declared theme, measured font metrics and prepared source assets. The host performs actual media assembly and caption management. Extensions are compiled ES modules explicitly allowlisted by the operator, with manifest code hashes. They run as trusted code, not in a security sandbox. Nontrivial dependencies must be vendored/licensed or provisioned explicitly; only the entry module is currently pinned by the extension loader.

The bundled external `callout` example is a minimal API proof, not a polished generic motion toolkit. It has conservative bounds. Production extensions should use measured glyph widths and their own negative-control tests.

## Audio interchange

Per-scene `narration.audio: {path, sha256}` accepts mono PCM16 WAV. All scene WAVs in a build share one rate. Or supply a `speech.json` with `schemaVersion`, engine identity and segment records: id, original text, spokenText, relative WAV path, SHA-256, native sample rate/count and measured duration. The importer re-measures WAVs, checks identities and source wording, and does not trust caller duration estimates. Pronunciation expansion uses `spokenText`; that is an explicit author decision, not a license to omit operative wording.

## Output interchange

`render-manifest.json` exposes project/video hashes, plugin versions, fonts, scene frame intervals, source identities, measured audio hashes, technical audit and review state. `prepared.json` is an execution-local intermediate with absolute paths/data URIs; use the project and source assets, not that file alone, for portability. Frame SVGs stay editable. Captions and chapter timestamps derive from native speech sample counts and encoded frame boundaries.

## MCP

Supported tested initialize protocol: `2025-11-25`; `2025-06-18` accepted by the same local transport. Tools use relative workspace paths. `video_render` writes a new directory and can take time; this implementation queues requests serially and does not expose async tasks or implement mid-render cancellation. It does not expose arbitrary shell commands, publishing or payment tools. The MCP interface is local integration, not universal certification across clients.

## Semantic versioning

Package versions, project schema and scene API are independent. Backward-incompatible schema/scene interfaces need a major version. Additive adapters can use minor package updates. Capture every project/asset/voice/rubric identity with the candidate. Rubric changes require a new series and fresh baseline; do not compare old OBC scores to this fresh technical series.
