# EMBLEM-NLP Reusable Video Plugins — 1.0.1

**Reusable tools, not an OBC lesson package.** Start a different subject by supplying a different project manifest, theme, source assets and narration. No lesson count, Code citation, previous-video directory or client identity is required by the new core.

## Packages and boundaries

| Package | Responsibility | Runtime entry |
|---|---|---|
| `emblem-nlp-video-factory` | Validate and plan a project; render seven scene types; import original PDF/image evidence; compose audio-led MP4, chapters and one optional native caption track | `node emblem-nlp-video-factory/dist/cli.js` |
| `emblem-nlp-neural-narration` | Generate checked, resumable local neural WAVs; preserve submitted text and explicit pronunciation strings | `python emblem-nlp-neural-narration/src/voice.py` |
| `emblem-nlp-video-rsi` | Audit the scoring scale, fresh technical observations, paired comparison, and the unchanged legacy RSI suite | `python emblem-nlp-video-rsi/src/rsi.py` |

The all-in-one ZIP and the three individual plugin ZIPs are **alternative installations of the same files**. Do not register both copies in a host. The heavy neural runtime is a separate optional artifact. The proof archive contains example projects and actual generated media; it is not required for a new project.

## Quick start — no model or paid service needed for a visual smoke test

From this bundle directory, after extracting:

```sh
node emblem-nlp-video-factory/dist/cli.js doctor
node emblem-nlp-video-factory/dist/cli.js validate --project emblem-nlp-video-factory/examples/silent-square/project.json
node emblem-nlp-video-factory/dist/cli.js render --project emblem-nlp-video-factory/examples/silent-square/project.json --out builds/first-preview
```

`builds/first-preview` must not exist yet. This example is explicitly **silent-preview**; it is never labelled fully narrated. The normal result is `video.mp4`, editable frame SVGs, subtitle files when applicable, a measured timeline, a render manifest and media audit.

## Fully narrated project

Use `emblem-nlp-video-factory/templates/project.json` or `examples/narrated-signal/project.json`. Supply one checked mono PCM16 WAV per scene, all at the same native sample rate, OR install the separate local neural runtime. Do not use both as automatic fallback choices.

```sh
python emblem-nlp-neural-narration/src/install_offline.py --archive /path/EMBLEM-NLP_Offline_Neural_Runtime_Linux_Py313.zip --out runtime
node emblem-nlp-video-factory/dist/cli.js render --project emblem-nlp-video-factory/examples/narrated-signal/project.json --voice-runtime runtime --out builds/narrated
```

The supplied offline wheel bundle requires **Linux x86_64 and CPython 3.13**. It contains actual model assets and dependencies, not just a download script. Installation validates the pinned outer ZIP and internal files, then installs without a package index. The runtime is not bundled into these small plugin ZIPs. Other platforms can provide their own compatible runtime but were not tested here.

## Staged operation for hosts with short tool time limits

```sh
runtime/.venv/bin/python emblem-nlp-neural-narration/src/voice.py synthesize --runtime runtime --profile emblem-nlp-neural-narration/profiles/ljspeech-high.json --script emblem-nlp-video-factory/examples/narrated-signal/speech.request.json --out builds/speech
node emblem-nlp-video-factory/dist/cli.js render --project emblem-nlp-video-factory/examples/narrated-signal/project.json --speech builds/speech/speech.json --out builds/narrated-staged
```

The audio stage validates a request identity and resumes verified utterances. Rendering is a new immutable build; it does **not** resume arbitrary partial picture files. For a new project, author a speech request with the same scene IDs, complete text and pronunciation strings as its manifest. The renderer rejects mismatches.

## What can change without editing the core

Subject, title, brand, source paths and hashes, source PDF pages and crops, scene count/order, given/missing inputs, table headings/cells/notes, flow labels, diagram geometry, recall prompts, complete reading text, theme colours and host font families, canvas geometry/cadence, teaching holds and supplied audio. Custom **trusted** scene extensions can be loaded with `--plugin PATH`.

Seven builtins: `inquiry`, `flow` (ordered consecutive handoffs), `table`, `figure`, `diagram`, `reading`, `recall`. A general branching graph is not disguised as the ordered-flow layout: use diagram geometry or an extension. More detailed scene geometry/animation remains a project-authoring task, not an automatic source-document interpretation claim.

## Interoperability

- **CLI:** validate / plan / render / inspect / doctor.
- **Node/TypeScript API:** compiled ES modules and declaration files; no TypeScript compiler needed to run the shipped build.
- **MCP:** local newline-delimited JSON-RPC stdio server; four tools: `video_doctor`, `video_validate`, `video_plan`, `video_render`. Render through MCP uses supplied WAVs or explicit silent mode; trusted voice setup stays in the CLI/skill workflow. Workspace containment is enforced. No web server is exposed.
- **Agent/Claude structure:** `.claude-plugin/plugin.json`, `skills/.../SKILL.md`, and core `.mcp.json` are supplied. Actual Claude/Cursor host installation was not performed; local protocol round trips and a real MCP render were performed.
- **New chat/container:** upload this all-in-one tools ZIP and your project assets. Add the separate runtime ZIP for new local speech. Read `NEXT_CHAT_PROMPT.md`.

A ZIP uploaded to ChatGPT is not automatically a native installed app. These are executable tooling packages for an environment with code execution and the stated prerequisites.

## Prerequisites and scope

Actual runtime tested: Linux x86_64, Node 22.16.0, Python 3.13.5, FFmpeg/FFprobe, Fontconfig, CairoSVG, Pillow, NumPy, PyMuPDF; optional Piper 1.8.0 / ONNX Runtime 1.30.0. The source declares Node >=20 / Python >=3.11 for non-neural code; Windows/macOS/other interpreter versions were not executed here. Cairo and named fonts are system prerequisites. The shipped JS is compiled; `npm install` is only for rebuilding TypeScript development dependencies. No dependencies are silently downloaded by a render command.

Fonts are named and hash-recorded, never redistributed. Default examples use DejaVu Serif/Sans. The JSON schema is included; each scene plugin additionally validates its own data, and the real renderer rejects clipping/overflow rather than truncating source text.

## Audit and promotion

```sh
python emblem-nlp-video-rsi/src/rsi.py scales
python emblem-nlp-video-rsi/src/rsi.py audit --build builds/narrated --project emblem-nlp-video-factory/examples/narrated-signal/project.json --out builds/audit
python emblem-nlp-video-rsi/src/rsi.py qualify --out builds/legacy-qualification
python emblem-nlp-video-rsi/src/rsi.py dual --reference /path/original.mp4 --candidate builds/narrated/video.mp4 --out builds/paired-review
```

The fresh technical score is **not** a visual-appeal, semantic accuracy, naturalness or learner score. Unknown values stay unknown. Human release approval is always separate. The exact legacy suite ZIP is preserved with its original internal history and rubric names; the generic adapter does not fabricate pristine-source status or mutate its thresholds. A legacy preflight blocker remains a blocker.

## Preservation policy

One optional native CC track, no burned transcript panel; at least 20% caption reserve. Measured speech controls scene duration. No waveform pitch/time shifting, no formant-waveform fallback. Complete source readings are not ellipsized; long content must be split into additional declared scenes. Original sources retain provenance and hashes; authored diagrams and schematic scale are labelled. Captions are estimated phrases inside measured audio spans, not forced word alignment or certified iPhone accessibility behaviour.

Read `BRANDING_MIGRATION.md`, `VALIDATION_REPORT.md`, `INTEROPERABILITY.md`, `MIGRATION.md` and the component READMEs before production use.
