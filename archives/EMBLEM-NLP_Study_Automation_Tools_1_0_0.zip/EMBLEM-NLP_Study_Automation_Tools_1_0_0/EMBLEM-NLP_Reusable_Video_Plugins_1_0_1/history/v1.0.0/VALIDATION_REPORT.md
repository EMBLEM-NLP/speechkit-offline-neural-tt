# Executed portability and plugin validation

The new tools actually rendered a **seven-scene narrated signal-flow explainer** (115.6667 seconds, 1080×1920, 30 fps), a **two-scene square process example** (15 seconds, 1080×1080, 24 fps), and a **custom external scene plugin** (6 seconds). The square example was rendered again through an actual local MCP tools/call request. Silent tests are explicitly marked silent; the signal-flow example has real locally synthesized Piper speech.

## Executed checks

- 40 Node contract/negative-control tests, 12 media-helper tests, 11 speech-contract tests and 16 RSI-adapter tests: **79 new unit tests**, all passed.
- The original unchanged RSI suite: **158 qualification tests passed**, zero failures/errors/skips. This is one set of software fixtures; rerunning it is not counted as 316 distinct tests.
- Ten local MCP lifecycle/tool/containment checks passed, including a real render.
- Five project JSON examples and the generated speech exchange validate against their schemas.
- The completed tools ZIP was extracted to a different directory, verified, validated and used to render the external plugin while the process working directory was /tmp. The original source folder was not required. This ran before the report-only final reseal.
- All seven scene families produced byte-identical source SVGs on repeated same-host/time calls. This is not cross-platform font equality or neural resynthesis determinism.
- The seven real neural WAV segments resumed from their verified cache without changing hashes. No robotic waveform fallback or external speech API was invoked.
- Actual video frame counts, complete decoding, audio duration/ending and native CC structure were checked. The narrated demo's full decoded-audio correlation with its actual PCM is approximately **0.999834**.

## Fresh scale and diagnostic loop

The technical rubric was structurally audited before use: unique dimensions, finite positive weights totalling 100, explicit [0,1] dimension ranges and [0,100] result. This is an engineering scale, **not an empirically calibrated drawing/learner rubric**. Historical OBC scores were not imported.

A deliberately deficient low-contrast calibration fixture scored **80/100**; the corrected theme scored **100/100** on the same scale, with no critical regression. This only proves the finite contrast/technical regression mechanism detects the constructed defect. It is not a claim of 100% visual communication, automatic design improvement, or learner mastery. The patch was operator-authored; the adapter does not autonomously design a new illustration. The actual full-length dual-review movie is in the separate proof package.

The original reconstruction-oriented RSI was also invoked on the first **20 seconds** of the actual pair. It returned **MEDIA_PREFLIGHT_BLOCKED / exit 3**: the authored baseline is not established as pristine, and no calibrated independent acceptance contract/review was supplied. Those blockers remain unchanged. The full video also received the separate generic technical audit; the 20-second legacy run is not represented as a full-film evaluation.

## Environment and repairs

The supplied complete neural ZIP was installed offline into a new local runtime and used for synthesis. Its older version lock lacked pip hashes: the installer now derives wheel hash requirements only after validating the entire pinned archive and internal SHA256SUMS. One initial all-in-one render call hit the host time limit. Seven complete verified utterances survived; a staged --speech build reused them successfully. That interrupted directory is not delivered as a successful output.

The new core has no dependency on old OBC lesson paths or fixed eight-question loops. It was rebuilt from generic contracts, not represented as an exhaustive port of every historic specialty diagram. The separate runtime archive is Linux x86_64/CPython3.13-specific. Actual Claude/Cursor installation, physical iPhone CC overrides, force-aligned words, independent spoken-content/voice review and learner comprehension remain untested.

## Packages and rights

The all-in-one and individual plugin ZIPs contain the same tools and are alternative installs. The proof, heavy runtime and new client project are separate. No font binaries are packaged. Third-party runtime and original RSI notices remain in their respective archives; the new owner-authored project code is private/UNLICENSED pending the owner's licensing decision.

See VALIDATION_SUMMARY.json and the separate proof reports for exact output identities and executed scope.
