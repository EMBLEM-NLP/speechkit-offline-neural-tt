# EMBLEM-NLP Video RSI Adapter — 1.0.1

This package has **two deliberately separate paths**:

1. A new, simple **technical diagnostic series** checking actual encoded media, caption reserve, theme contrast, text bounds, declared scale and source hashes.
2. The original `RSI_TEST_SUITE_1_2_0_OBC_COMMUNICATION.zip`, unchanged and hash-locked, invoked by qualify/legacy. Its old client-specific rubrics are historical contents, not new project measurements.

```sh
python src/rsi.py scales
python src/rsi.py audit --build /workspace/build --project /workspace/project.json --out /workspace/audit
python src/rsi.py compare --baseline /workspace/audit-0/TECHNICAL_AUDIT.json --candidate /workspace/audit-1/TECHNICAL_AUDIT.json --out /workspace/promotion.json
python src/rsi.py dual --reference /workspace/original.mp4 --candidate /workspace/candidate.mp4 --out /workspace/dual
python src/rsi.py qualify --out /workspace/qualification
python src/rsi.py legacy --reference /workspace/original.mp4 --candidate /workspace/candidate.mp4 --out /workspace/legacy --seconds 20
```

`audit` is currently an adapter for the core's output contract. Other renderers must supply equivalent scene/source/layout evidence, not just a naked MP4. `dual` and legacy media input are renderer-independent.

The technical rubric totals 100: media25, caption reserve20, theme contrast20, text bounds15, scale disclosure10 and source identity10. Dimension values are binary engineering checks in [0,1]. The 4.5 contrast threshold checks authored ink/accent/muted on paper/surface; it is not comprehensive WCAG certification. Scale checks enforce disclosure and the renderer's shared X/Y fitting policy, not correctness of a building dimension or scientific model. With no source assets, source identity is a vacuous pass because nothing is claimed as an external source; it is not corroboration of the narration.

Missing ratings stay null and cannot produce a score. Changed rubric identities cannot be compared. Critical regressions prevent technical promotion. **A 100 technical result is not 100% communication, design, naturalness or learner comprehension.** ReleaseApproved remains false. Add actual human review separately; never fill missing learner evidence with a producer proxy.

The dual movie is actual-time, original left / candidate right, with visible date/time/timezone, elapsed time, review frame and workflow labels outside artwork. Only candidate audio is audible. No duration normalization and no original-as-candidate substitution are allowed. Explicit end slates handle shorter clips. The output is a diagnostic comparison, not the distribution version with captions.

The underlying legacy suite can reject authored references as non-pristine or lack a calibrated independent acceptance contract. Preserve that report and exit code. The first-N-seconds option is explicit, not full-film validation. The original 158 fixture qualification tests test software, not your film's quality.

Prerequisites: Python with requirements.txt, FFmpeg/FFprobe and Fontconfig. Run `python -m unittest discover -s tests -v` for adapter controls. Legacy qualifying/analysis commands require a new output folder.
