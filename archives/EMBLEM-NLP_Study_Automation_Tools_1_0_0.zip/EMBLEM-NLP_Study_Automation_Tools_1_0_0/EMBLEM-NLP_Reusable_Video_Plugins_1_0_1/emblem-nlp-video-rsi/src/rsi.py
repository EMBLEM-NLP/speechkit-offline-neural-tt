"""Renderer-independent adapter: fresh technical observations, original RSI, and actual paired review."""
from __future__ import annotations
import argparse,hashlib,json,math,subprocess,sys,zipfile
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1] # No client-project paths are hard-coded.

def sha(file):
    h=hashlib.sha256()
    with Path(file).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def load(file):return json.loads(Path(file).read_text()) # Caller-provided evidence, never guessed newest files.

def save(file,value):
    p=Path(file);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')

def scales(file):
    r=load(file);ds=r.get('dimensions',[])
    if r.get('range')!=[0,100] or not ds or len({x['id'] for x in ds})!=len(ds):raise ValueError('Invalid rubric range or duplicate dimensions')
    if any(x.get('range')!=[0,1] or isinstance(x['weight'],bool) or not isinstance(x['weight'],(int,float)) or not math.isfinite(x['weight']) or x['weight']<=0 for x in ds):raise ValueError('Invalid dimension scale')
    if abs(sum(x['weight'] for x in ds)-100)>1e-8:raise ValueError('Weights must sum to 100')
    return {'status':'SCALE_STRUCTURE_VALID','rubricId':r['id'],'rubricSha256':sha(file),'weightSum':100,'calibration':'Engineering thresholds; NOT learner-calibrated','carryForwardScores':False}

def score(rubric,values):
    known={d['id'] for d in rubric['dimensions']}
    if set(values)!=known:raise ValueError('Missing/unknown metric')
    for v in values.values():
        if v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=1):raise ValueError('Metric outside 0..1')
    if any(v is None for v in values.values()):return None # Unknown observations are not assigned a fabricated midpoint.
    return round(sum(d['weight']*values[d['id']] for d in rubric['dimensions']),4)

def contrast(a,b):
    def luminance(h):
        v=[int(h[i:i+2],16)/255 for i in (1,3,5)];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
        return .2126*v[0]+.7152*v[1]+.0722*v[2]
    x,y=sorted([luminance(a),luminance(b)]);return (y+.05)/(x+.05) # Contrast of authored theme text, not every pixel of source imagery.

def audit(build,project,out,rubric_path=None):
    import cv2,numpy as np
    from PIL import Image
    build=Path(build).resolve();project=Path(project).resolve();out=Path(out).resolve();rubric_path=Path(rubric_path or ROOT/'rubrics/technical-v1.json');scale=scales(rubric_path);r=load(rubric_path)
    manifest=load(build/'render-manifest.json');job=load(build/'prepared.json');frames=load(build/'frames.json')['frames'];places=load(build/'text-placements.json');source=load(project)
    if len([f for f in frames if f['settled']])!=len(job['scenes']):raise ValueError('Incomplete settled-state coverage')
    if sha(project)!=manifest['projectSha256']:raise ValueError('Project identity differs from render')
    media_ok=sha(build/manifest['video'])==manifest['videoSha256']
    result=subprocess.run(['ffmpeg','-v','error','-i',str(build/manifest['video']),'-map','0:v:0','-map','0:a?','-f','null','-'],capture_output=True)
    media_ok=media_ok and result.returncode==0 and not result.stderr
    cap=cv2.VideoCapture(str(build/manifest['video']));state_checks=[];caption_ok=True
    band=int(source['canvas']['height']*(1-source['canvas']['captionReserve']))
    for sc,f in zip(job['scenes'],[f for f in frames if f['settled']]):
        index=min(sc['endFrame']-1,sc['startFrame']+sc['transitionFrames']+3);cap.set(cv2.CAP_PROP_POS_FRAMES,index);ok,im=cap.read()
        if not ok:raise ValueError('Missing encoded scene frame')
        im=cv2.cvtColor(im,cv2.COLOR_BGR2RGB);original=np.asarray(Image.open(build/f['png']).convert('RGB'))
        mae=float(np.mean(np.abs(im.astype(float)-original.astype(float))));std=float(im[band+4:].astype(float).std(axis=(0,1)).max());caption_ok=caption_ok and std<1.5;media_ok=media_ok and mae<=r['encodedStateMaeMaximum']
        state_checks.append({'sceneId':sc['id'],'encodedFrame':index,'encodedMae':mae,'captionBandStd':std,'sourcePngSha256':sha(build/f['png'])})
    cap.release();bounds_ok=all(t['x']>=0 and t['y']>=0 and t['x']+t['width']<=source['canvas']['width']+.1 and t['y']+t['height']<=band+.1 for p in places for t in p['text'])
    ratios={k+'_'+bg:contrast(source['theme'][k],source['theme'][bg]) for k in ['ink','accent','muted'] for bg in ['paper','surface']}
    diagrams=[s for s in source['scenes'] if s['plugin']=='diagram'];scale_ok=all(s['data'].get('scale',{}).get('mode') in ('uniform','schematic') for s in diagrams)
    asset_checks=[]
    for a in source['assets']:
        p=(project.parent/a['path']).resolve()
        if not p.is_relative_to(project.parent):raise ValueError('Source path escaped project')
        asset_checks.append({'id':a['id'],'matches':sha(p)==a['sha256']})
    values={'media':int(bool(media_ok)),'caption_reserve':int(bool(caption_ok)),'theme_contrast':int(min(ratios.values())>=r['contrastMinimum']),'text_bounds':int(bounds_ok),'scale_disclosure':int(scale_ok),'source_identity':int(all(a['matches'] for a in asset_checks))}
    report={'schemaVersion':'1.0.0','status':'TECHNICAL_DIAGNOSTIC_COMPLETE','series':scale,'videoSha256':manifest['videoSha256'],'projectSha256':manifest['projectSha256'],'score':score(r,values),'dimensions':values,'scenes':state_checks,'contrastRatios':ratios,'sourceIdentities':asset_checks,'scaleScope':'Checks explicit schematic/uniform disclosure and renderer uniform-fit contract, NOT engineering dimensional correctness','humanCommunicationScore':None,'naturalnessScore':None,'learnerTransfer':None,'releaseApproved':False,'generatedAt':datetime.now(ZoneInfo('America/Toronto')).isoformat()}
    save(out/'TECHNICAL_AUDIT.json',report);save(out/'SCALE_AUDIT.json',scale);return report

def compare(baseline,candidate,out,rubric_path=None):
    a,b=load(baseline),load(candidate);rp=Path(rubric_path or ROOT/'rubrics/technical-v1.json');scales(rp);r=load(rp)
    if a['series']['rubricSha256']!=b['series']['rubricSha256']:raise ValueError('Cannot compare different measurement series')
    if a['series']['rubricSha256']!=sha(rp):raise ValueError('Comparison rubric does not match the evidence series')
    if any(score(r,x['dimensions'])!=x['score'] for x in (a,b)):raise ValueError('Reported score does not match its measurements')
    if a['videoSha256']==b['videoSha256']:raise ValueError('Candidate equals baseline; no independent improvement candidate')
    delta=None if a['score'] is None or b['score'] is None else b['score']-a['score']
    regression=any(d['critical'] and a['dimensions'][d['id']] is not None and (b['dimensions'][d['id']] is None or a['dimensions'][d['id']]>b['dimensions'][d['id']]) for d in r['dimensions'])
    critical_pass=all(b['dimensions'][d['id']]==1 for d in r['dimensions'] if d['critical'])
    result={'status':'TECHNICAL_COMPARISON_ONLY','baselineScore':a['score'],'candidateScore':b['score'],'delta':delta,'criticalRegression':regression,'technicalPromotionEligible':delta is not None and delta>=r['technicalPromotionMinimumGain'] and not regression and critical_pass,'releaseApproved':False,'humanReviewRequired':True,'rubricSha256':a['series']['rubricSha256']}
    save(out,result);return result # The renderer/agent may patch, but independent acceptance is never fabricated.

def extract_suite(work):
    lock=load(ROOT/'vendor/LOCK.json');archive=ROOT/'vendor'/lock['archive']
    if sha(archive)!=lock['sha256']:raise ValueError('Original RSI archive changed')
    work=Path(work);work.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for i in z.infolist():
            p=Path(i.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or ((i.external_attr>>16)&0o170000)==0o120000:raise ValueError('Unsafe suite member')
        z.extractall(work)
    return work/'RSI_TEST_SUITE'

def qualify(out):
    out=Path(out)
    if out.exists():raise ValueError('Use a new qualification directory')
    suite=extract_suite(out/'suite');r=subprocess.run([sys.executable,str(suite/'run_suite.py'),'--self-test','--out',str(out/'run')],capture_output=True,text=True)
    (out/'ORIGINAL_SUITE.log').write_text(r.stdout+r.stderr);result={'returncode':r.returncode,'report':str(out/'run/RUN_SUMMARY.json'),'suiteArchiveUnchanged':True,'mediaCertified':False};save(out/'ADAPTER_RESULT.json',result)
    if r.returncode:raise ValueError('Original RSI software qualification failed')
    return result

def legacy(reference,candidate,out,seconds=20):
    out=Path(out)
    if out.exists():raise ValueError('Use a new legacy RSI directory')
    suite=extract_suite(out/'suite');a,b=Path(reference),Path(candidate)
    if sha(a)==sha(b):raise ValueError('Reference and candidate are identical')
    bundle={'schema_version':'1.0','reference':{'path':'reference.mp4','sha256':sha(a),'provenance':'direct_render','label':'Authored baseline, not a pristine reconstruction source'},'candidate':{'path':'candidate.mp4','sha256':sha(b),'provenance':'direct_render','label':'New-project candidate'},'profile':'full'}
    with zipfile.ZipFile(out/'media.zip','w',compression=zipfile.ZIP_STORED) as z:z.write(a,'reference.mp4');z.write(b,'candidate.mp4');z.writestr('video_bundle.json',json.dumps(bundle))
    args=[sys.executable,str(suite/'run_suite.py'),'--video-zip',str(out/'media.zip'),'--out',str(out/'run'),'--profile','full','--duration-s',str(seconds),'--analysis-fps','1','--max-review-seconds',str(seconds)]
    p=subprocess.run(args,capture_output=True,text=True);(out/'ORIGINAL_SUITE.log').write_text(p.stdout+p.stderr)
    result={'returncode':p.returncode,'report':str(out/'run/RUN_SUMMARY.json'),'scope':f'Explicit first {seconds} seconds only','sourceProvenance':'direct_render','releaseApproved':False};save(out/'ADAPTER_RESULT.json',result);return result # Exit 3 review blockers remain blockers, not a false success.

def dual(reference,candidate,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);a,b=Path(reference),Path(candidate)
    if sha(a)==sha(b):raise ValueError('Reference equals candidate')
    def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(p)]))
    ia,ib=probe(a),probe(b);va=next(x for x in ia['streams'] if x['codec_type']=='video');vb=next(x for x in ib['streams'] if x['codec_type']=='video');duration=max(float(va['duration']),float(vb['duration']));fps=15;count=math.ceil(duration*fps)
    font=subprocess.check_output(['fc-match','-f','%{file}','DejaVu Sans']).decode();stamp=datetime.now(ZoneInfo('America/Toronto')).isoformat(timespec='seconds')+' America/Toronto'
    (out/'stamp.txt').write_text(stamp);picture=out/'dual-picture.mp4';video=out/'DUAL_REVIEW.mp4'
    filters=f"[0:v]drawtext=fontfile='{font}':text='ORIGINAL / BASELINE':x=18:y=20:fontsize=26:fontcolor=white,drawtext=fontfile='{font}':text='CANDIDATE':x=560:y=20:fontsize=26:fontcolor=white,drawtext=fontfile='{font}':text='END OF ORIGINAL':x=90:y=500:fontsize=28:fontcolor=white,drawtext=fontfile='{font}':text='END OF CANDIDATE':x=620:y=500:fontsize=28:fontcolor=white[base];[1:v]scale=540:960:force_original_aspect_ratio=decrease,pad=540:960:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,setpts=PTS-STARTPTS[a];[2:v]scale=540:960:force_original_aspect_ratio=decrease,pad=540:960:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,setpts=PTS-STARTPTS[b];[base][a]overlay=x=0:y=100:eof_action=pass:repeatlast=0:shortest=0[tmp];[tmp][b]overlay=x=540:y=100:eof_action=pass:repeatlast=0:shortest=0,drawtext=fontfile='{font}':textfile='{out/'stamp.txt'}':x=18:y=64:fontsize=18:fontcolor=white,drawtext=fontfile='{font}':text='Workflow paired review | elapsed %{{pts\\:hms}} | review frame %{{n}}':x=18:y=1080:fontsize=22:fontcolor=white[v]"
    args=['ffmpeg','-y','-v','error','-f','lavfi','-i',f'color=c=black:s=1080x1160:r={fps}:d={count/fps}','-i',str(a),'-i',str(b),'-filter_complex_threads','1','-filter_complex',filters,'-map','[v]','-map_metadata','-1','-map_chapters','-1','-frames:v',str(count),'-an','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p','-threads','2',str(picture)]
    p=subprocess.run(args,capture_output=True);(out/'dual-encode.log').write_bytes(p.stderr)
    if p.returncode or p.stderr:raise ValueError('Dual picture failed: '+p.stderr.decode()[-1200:])
    has_audio=any(s['codec_type']=='audio' for s in ib['streams']);args=['ffmpeg','-y','-v','error','-i',str(picture),'-i',str(b),'-map','0:v:0']
    if has_audio:args+=['-map','1:a:0','-c:a','copy']
    args+=['-map_metadata','-1','-map_chapters','-1','-c:v','copy','-movflags','+faststart',str(video)];p=subprocess.run(args,capture_output=True);(out/'dual-mux.log').write_bytes(p.stderr)
    if p.returncode or p.stderr:raise ValueError('Dual mux failed')
    p=subprocess.run(['ffmpeg','-v','error','-i',str(video),'-map','0:v:0','-map','0:a?','-f','null','-'],capture_output=True)
    if p.returncode or p.stderr:raise ValueError('Dual decode failed')
    result={'video':str(video),'sha256':sha(video),'frames':count,'fps':fps,'durationSeconds':count/fps,'referenceSha256':sha(a),'candidateSha256':sha(b),'labelsOutsideArtwork':True,'candidateAudioOnly':True,'dateTime':stamp,'alignment':'same actual elapsed time; no duration normalization','decode':'PASS'};save(out/'DUAL_MANIFEST.json',result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['scales','audit','compare','qualify','legacy','dual']);p.add_argument('--build');p.add_argument('--project');p.add_argument('--out');p.add_argument('--rubric');p.add_argument('--baseline');p.add_argument('--candidate');p.add_argument('--reference');p.add_argument('--seconds',type=int,default=20);a=p.parse_args()
    if a.command=='scales':v=scales(a.rubric or ROOT/'rubrics/technical-v1.json')
    elif a.command=='audit':v=audit(a.build,a.project,a.out,a.rubric)
    elif a.command=='compare':v=compare(a.baseline,a.candidate,a.out,a.rubric)
    elif a.command=='qualify':v=qualify(a.out)
    elif a.command=='legacy':v=legacy(a.reference,a.candidate,a.out,a.seconds)
    else:v=dual(a.reference,a.candidate,a.out)
    print(json.dumps(v,indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:print(json.dumps({'status':'EXECUTION_BLOCKED','error':str(e),'releaseApproved':False}),file=sys.stderr);sys.exit(2)
