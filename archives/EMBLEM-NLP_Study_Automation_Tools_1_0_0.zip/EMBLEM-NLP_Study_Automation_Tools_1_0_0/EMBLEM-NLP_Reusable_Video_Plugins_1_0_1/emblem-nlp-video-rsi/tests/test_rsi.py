"""Fresh technical-score scale controls, not subjective visual ratings."""
import copy,importlib.util,json,tempfile,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[1];sp=importlib.util.spec_from_file_location('rsi',root/'src/rsi.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
R=json.loads((root/'rubrics/technical-v1.json').read_text())
class RSITests(unittest.TestCase):
 def values(self):return {d['id']:1 for d in R['dimensions']}
 def test_scales(self):self.assertEqual(m.scales(root/'rubrics/technical-v1.json')['weightSum'],100)
 def test_full_score(self):self.assertEqual(m.score(R,self.values()),100)
 def test_failed_contrast(self):
  v=self.values();v['theme_contrast']=0;self.assertEqual(m.score(R,v),80)
 def test_unmeasured_not_zero(self):
  v=self.values();v['media']=None;self.assertIsNone(m.score(R,v))
 def test_out_of_range(self):
  v=self.values();v['media']=2
  with self.assertRaises(ValueError):m.score(R,v)
 def test_nan(self):
  v=self.values();v['media']=float('nan')
  with self.assertRaises(ValueError):m.score(R,v)
 def test_bool_not_numeric(self):
  v=self.values();v['media']=True
  with self.assertRaises(ValueError):m.score(R,v)
 def test_unknown_metric(self):
  v=self.values();v['learner']=1
  with self.assertRaises(ValueError):m.score(R,v)
 def test_missing_metric(self):
  v=self.values();del v['media']
  with self.assertRaises(ValueError):m.score(R,v)
 def bad_rubric(self,mutate):
  with tempfile.TemporaryDirectory() as d:
   r=copy.deepcopy(R);mutate(r);p=Path(d)/'rubric.json';p.write_text(json.dumps(r))
   with self.assertRaises(ValueError):m.scales(p)
 def test_wrong_weight_total(self):self.bad_rubric(lambda r:r['dimensions'][0].update(weight=20))
 def test_duplicate_dimension(self):self.bad_rubric(lambda r:r['dimensions'].append(r['dimensions'][0]))
 def test_wrong_dimension_scale(self):self.bad_rubric(lambda r:r['dimensions'][0].update(range=[0,5]))
 def test_black_white_contrast(self):self.assertAlmostEqual(m.contrast('#000000','#FFFFFF'),21)
 def test_equal_contrast(self):self.assertEqual(m.contrast('#AAAAAA','#AAAAAA'),1)
 def test_same_video_comparison_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.json';p.write_text(json.dumps({'series':{'rubricSha256':'x'},'videoSha256':'same'}))
   with self.assertRaises(ValueError):m.compare(p,p,Path(d)/'out.json')
 def test_different_series_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   a,b=Path(d)/'a.json',Path(d)/'b.json';a.write_text(json.dumps({'series':{'rubricSha256':'a'}}));b.write_text(json.dumps({'series':{'rubricSha256':'b'}}))
   with self.assertRaises(ValueError):m.compare(a,b,Path(d)/'out.json')
if __name__=='__main__':unittest.main()
