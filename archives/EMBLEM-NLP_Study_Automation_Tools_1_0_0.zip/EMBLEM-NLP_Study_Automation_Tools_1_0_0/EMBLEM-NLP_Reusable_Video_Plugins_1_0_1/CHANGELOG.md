# 1.0.1 — EMBLEM-NLP naming correction

Canonical package/plugin paths, private package namespace, MCP registration, display branding, example header, documentation and download references corrected. Legacy Python environment variable retained as fallback; exchange schemas, scene API, voice profile and sealed RSI identities unchanged. All checksums regenerated for the new release. See BRANDING_MIGRATION.md.

# 1.0.0
Initial generic, project-separated implementation derived from the production lessons of the supplied OBC tooling. Adds compiled TypeScript scene API, seven data-driven renderers, explicit trusted extension loading, measured-PCM media assembly, local neural speech interchange, CLI/Node/MCP interfaces, fresh technical diagnostics, exact legacy RSI wrapper and separate provenance/review artifacts. This starts a new reusable product version; it does not rename OBC v4.5 as a generic package.
