# EMBLEM-NLP reusable video plugins — validation 1.0.1

Generated 2026-10-02T22:34:18-04:00.

**Branding correction implemented and exercised.** All new display brands, canonical component directories/IDs, private package namespaces, MCP registration/examples, documentation, runtime-download references and the branded example now use EMBLEM-NLP.

The compiled JavaScript was regenerated from TypeScript. The renderer locates `emblem-nlp-neural-narration` as its sibling provider; `EMBLEM_NLP_PYTHON` takes precedence over the retained legacy variable. API/schema versions stay at 1.0.0. Update old host paths/registrations once; do not register both distributions.

## Checks executed on this release

| Check | Result |
|---|---:|
| Node source/regression tests, including 6 branding/compatibility cases | 46 passed |
| Python media tests | 12 passed |
| Python narration tests | 11 passed |
| Python RSI adapter tests | 16 passed |
| Total source/regression tests | **85 passed** |
| Unchanged RSI software qualification | **158 passed; no failures/errors/skips** |
| Local MCP initialize, list, validate and plan | **4 passed** |
| TypeScript compilation | Passed |
| Actual compiled-core render with corrected brand | Passed; explicit silent test, no speech generated |

The branded rendered checkpoint was visually inspected: EMBLEM-NLP appears correctly and fits the existing header. It is a name/layout smoke check, not an independent quality score. Test logs and the actual RSI run summary are under `reports/`.

The sealed RSI tool, technical-rubric bytes/measurement series, source PDF, voice profile, neural synthesis implementation and third-party license notices match their predecessors. The external offline runtime is byte-identical under a corrected download filename; its pinned SHA-256 remains unchanged. It was verified, not installed or resynthesized in this branding turn.

Old validation records are retained verbatim under `history/v1.0.0/`. Existing delivered course/demo MP4s and original ZIPs are not overwritten. This patch changes future renders of the bundled branded example; caller-supplied project branding remains caller data.

See `BRANDING_MIGRATION.md` for intentional historical/compatibility names that are not commercial display branding. No fonts, new models or paid-service credentials are distributed by these small plugins.
