# Migration from the OBC production packages

This is a **new generic implementation of the reusable contracts**, not a claim that every OBC-specific renderer was automatically converted or that the full 79-minute OBC course was re-rendered through it.

Removed dependencies: `OBC_V43_ROOT`, numbered lesson loops, Code-specific SQLite queries, fixed PDF coordinates, copied prior-year narratives, hard-coded Q1/Q4 profiles, previous-version delivery filenames and fixed client branding. The original source packages remain untouched.

Retained production lessons: separate picture/audio muxing; reject FFmpeg error-level stderr even with exit 0; RGB raster consistency; actual frame-count/full-decode checks; hashed native speech and source assets; 20% caption reserve; full reading coverage; explicit figure provenance; dynamic scene counts; review-required release status.

Not claimed as builtins in 1.0.0: every historic bespoke theatrical/guard/CO diagram, the exact OBC TOC-link extractor, an automatic arbitrary-PDF table parser, universal chapter-to-Code mappings, general branching graph layout, cloud speech APIs, autonomous creative direction, forced word alignment, or a calibrated visual/learner quality evaluator. Represent those as new scene data or explicitly authored extensions.

## Move a different project

1. Copy the new starter outside the tooling folder.
2. Declare the new subject, theme and canvas; keep source assets in the project.
3. Choose builtins or explicitly trusted scene extensions. Add scenes rather than shrinking/truncating text.
4. Supply complete narration or existing checked WAVs; keep silence/recall holds explicit.
5. Validate, plan, render, audit, review and archive the project separately from the plugins.

The synthetic low-contrast baseline in the proof package only tests diagnostic sensitivity. It is not a new OBC drawing audit or a user-approved style baseline.
