---
name: neural-narration
description: Generate neural narration using local identity-checked source assets and explicit project manifests.
disable-model-invocation: true
---

Read the plugin README and the user's new-project brief. Treat this as trusted executable code, not a prompt-only renderer. Invoke `python "${CLAUDE_PLUGIN_ROOT}/src/voice.py"` with the documented arguments. Check actual local files and dependencies first. Do not infer prior OBC topics, hard-coded page numbers, answers, themes or scene counts. Do not turn silent preview into a claimed narrated deliverable.

Preserve original evidence and complete narration. Keep caption-safe layout and one native optional CC track. Add scenes rather than truncate a clause. Do not load untrusted scene code or download paid services silently. Respect runtime platform constraints and model licenses. Use actual tests, media identity and full-decode evidence. Keep independent naturalness, semantic correctness and learner comprehension unmeasured until reviewed. Preserve before/after movies with date/time/timezone/frame labels. The artifact is not approved merely because a numeric technical diagnostic increases.
