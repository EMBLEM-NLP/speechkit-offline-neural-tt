# Rights and third-party components
This new project source is distributed as private, unlicensed project code. No public open-source license has been granted for it here. The owner may choose an appropriate license before redistribution.

Referenced or separately bundled tools retain their own notices and license obligations. In particular the external Piper distribution, pronunciation libraries and voice model must be checked individually; they are not relicensed by this wrapper. The optional runtime archive preserves its third-party notices and source archives. The unchanged RSI archive retains its supplied metadata and notices.

No font binaries, OBC source-page assets, or previous client lesson movies are included in the new core or example projects. The unchanged legacy RSI archive retains its historical OBC test fixtures and validation records. Fonts must be supplied by the host under appropriate rights. The small example PDF is newly authored demo content, not an official manual.
