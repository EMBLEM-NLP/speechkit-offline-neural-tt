# EMBLEM-NLP Neural Narration — 1.0.1

This adapter uses explicitly selected local Piper model assets. It does not attempt Kokoro or a network API, and does not fall back to Flite/eSpeak audible output. Piper may use pronunciation symbols from eSpeak-ng internally; the waveform comes from the neural model.

The optional external `EMBLEM-NLP_Offline_Neural_Runtime_Linux_Py313.zip` is pinned by runtime-lock.json. Restore it with:

```sh
python src/install_offline.py --archive /path/EMBLEM-NLP_Offline_Neural_Runtime_Linux_Py313.zip --out /workspace/runtime
/workspace/runtime/.venv/bin/python src/voice.py doctor --runtime /workspace/runtime --profile profiles/ljspeech-high.json
/workspace/runtime/.venv/bin/python src/voice.py synthesize --runtime /workspace/runtime --profile profiles/ljspeech-high.json --script /workspace/speech.request.json --out /workspace/speech
```

Request format:

```json
{"schemaVersion":"1.0.0","id":"my-project","segments":[{"id":"intro","text":"Follow the signal.","spokenText":"Follow the signal."}]}
```

Output speech.json and hashed mono PCM16 WAVs are directly consumed by the core's `--speech`. All original text remains in each record. This is source-input coverage, not ASR or full human pronunciation verification. A listening approval is still required before a narrator is called natural enough for the project.

Source tests need only Python: `python -m unittest discover -s tests -v`. Inference needs the pinned runtime. Retrying synthesis into the same folder only resumes when request/profile and recorded WAV hashes agree. A changed script/profile requires a new folder; unknown partial WAVs never become approved cache entries.

Installer repair: the older runtime bundle's version lock does not contain pip hashes. The installer first verifies the complete archive and internal SHA256SUMS, then derives a hashed requirements file from wheel identities before `pip --no-index --require-hashes`. This actual installation path was executed successfully.

Piper and its dependencies/model retain their separate license notices in the external bundle. Do not assume the wrapper's project license relicenses the model or dependencies. No model or font binaries are hidden in this small plugin ZIP.
