"""Small pure-function and negative-control tests; not learner results."""
import importlib.util,json,tempfile,unittest,wave
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'python/media.py';sp=importlib.util.spec_from_file_location('media',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
class MediaTests(unittest.TestCase):
 def test_caption_word_coverage(self):
  text=' '.join(['Complete source wording must not disappear.']*7);self.assertEqual(' '.join(' '.join(m.phrase_chunks(text)).split()),text)
 def test_caption_max_two_lines(self):self.assertTrue(all(len(s.splitlines())<=2 for s in m.phrase_chunks('word '*100)))
 def test_caption_line_width(self):self.assertTrue(all(len(l)<=42 for s in m.phrase_chunks('source wording '*100) for l in s.splitlines()))
 def test_caption_huge_token(self):
  with self.assertRaises(ValueError):m.phrase_chunks('a'*50)
 def test_ass_centisecond(self):self.assertEqual(m.ass_time(61.235),'0:01:01.24')
 def test_path_traversal(self):
  with self.assertRaises(ValueError):m.contained(Path('.'),'../private.wav')
 def test_absolute_source(self):
  with self.assertRaises(ValueError):m.contained(Path('.'),'/private.wav')
 def wav(self,channels,samples):
  d=tempfile.TemporaryDirectory();p=Path(d.name)/'a.wav'
  with wave.open(str(p),'wb') as w:w.setparams((channels,2,22050,0,'NONE',''));w.writeframes(b'\0\0'*samples*channels)
  return d,p
 def test_empty_wave(self):
  d,p=self.wav(1,0)
  with d,self.assertRaises(ValueError):m.wave_info(p)
 def test_stereo_wave(self):
  d,p=self.wav(2,100)
  with d,self.assertRaises(ValueError):m.wave_info(p)
 def test_exact_sample_duration(self):
  d,p=self.wav(1,22050)
  with d:self.assertEqual(m.wave_info(p)['durationSeconds'],1)
 def test_stable_hash(self):
  d,p=self.wav(1,22050)
  with d:self.assertEqual(m.sha(p),m.sha(p))
 def test_empty_captions(self):
  with tempfile.TemporaryDirectory() as d:self.assertEqual(m.captions({},[],Path(d)),(None,[]))
if __name__=='__main__':unittest.main()
