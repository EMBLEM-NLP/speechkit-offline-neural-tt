import test from 'node:test'; // Use the same built-in test runner as the existing contracts.
import assert from 'node:assert/strict'; // Fail instead of silently accepting a stale identity.
import fs from 'node:fs'; // Read the actual shipped manifests and examples.
import path from 'node:path'; // Resolve sibling packages after relocation.
import {fileURLToPath} from 'node:url'; // Avoid fixed historical workspace paths.
import {py} from '../dist/factory.js'; // Test the compiled implementation used by consumers.
const core = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'); // Resolve the core root.
const bundle = path.dirname(core); // Resolve installed siblings.
const json = p => JSON.parse(fs.readFileSync(p, 'utf8')); // Parse the shipped JSON files.
for (const suffix of ['video-factory', 'neural-narration', 'video-rsi']) { // Check all component names.
  test(`Canonical package identity: ${suffix}`, () => { // Keep errors specific to their package.
    const directory = path.join(bundle, `emblem-nlp-${suffix}`); // Use the new canonical directory.
    if (!fs.existsSync(directory)) return; // Separate core ZIPs need not install optional siblings.
    const plugin = json(path.join(directory, 'plugin.json')); // Read the generic host manifest.
    const npm = json(path.join(directory, 'package.json')); // Read the private package identity.
    const claude = json(path.join(directory, '.claude-plugin/plugin.json')); // Read the host registration.
    assert.equal(plugin.id, `emblem-nlp-${suffix}`); // Require the canonical brand slug.
    assert.equal(npm.name, `@emblem-nlp/${suffix}`); // Require the corrected private namespace.
    assert.equal(claude.name, plugin.id); // Require agreement between host interfaces.
    assert.equal(claude.author.name, 'EMBLEM-NLP'); // Check the visible author brand.
    for (const value of [plugin, npm, claude]) assert.equal(value.version, '1.0.1'); // Track the patch version.
    assert.equal(plugin.apiVersion, '1.0.0'); // Preserve the existing interchange protocol.
  }); // Finish this component test.
} // Finish the component identity matrix.
test('Branded example and schema title use EMBLEM-NLP', () => { // Catch stale output labels.
  assert.equal(json(path.join(core, 'examples/narrated-signal/project.json')).brand, 'EMBLEM-NLP / PRODUCTION STUDIES'); // Check new-render artwork data.
  assert.match(json(path.join(core, 'schemas/project.schema.json')).title, /^EMBLEM-NLP /); // Check user-facing schema documentation.
}); // End the display-brand test.
test('Python selection supports the new name and the legacy fallback', () => { // Preserve old integrations.
  const current = process.env.EMBLEM_NLP_PYTHON; // Save the caller's current setting.
  const legacy = process.env.EMBLEM_PYTHON; // Save its compatibility setting.
  try { // Always restore environment state after the assertion sequence.
    delete process.env.EMBLEM_NLP_PYTHON; // Start without a canonical override.
    delete process.env.EMBLEM_PYTHON; // Start without a legacy override.
    assert.equal(py({}), 'python'); // Preserve the established default.
    process.env.EMBLEM_PYTHON = 'legacy-python'; // Supply only the compatibility alias.
    assert.equal(py({}), 'legacy-python'); // Prove old settings still resolve.
    process.env.EMBLEM_NLP_PYTHON = 'canonical-python'; // Supply the new canonical override.
    assert.equal(py({}), 'canonical-python'); // Prefer the new name over the alias.
    assert.equal(py({python:'explicit-python'}), 'explicit-python'); // Keep explicit caller selection first.
  } finally { // Restore both variables even when an assertion fails.
    if (current === undefined) delete process.env.EMBLEM_NLP_PYTHON; else process.env.EMBLEM_NLP_PYTHON = current; // Restore canonical input.
    if (legacy === undefined) delete process.env.EMBLEM_PYTHON; else process.env.EMBLEM_PYTHON = legacy; // Restore compatibility input.
  } // Finish the environment isolation block.
}); // End environment selection test.
test('MCP configuration points at the corrected executable registration', () => { // Verify host configuration.
  const servers = json(path.join(core, '.mcp.json')).mcpServers; // Read the current server map.
  assert.deepEqual(Object.keys(servers), ['emblem-nlp-video']); // Prevent duplicate old/new registrations.
  assert.equal(servers['emblem-nlp-video'].env.EMBLEM_NLP_PYTHON, 'python'); // Use canonical configuration spelling.
  assert.match(fs.readFileSync(path.join(core, 'dist/factory.js'), 'utf8'), /\.\.\/emblem-nlp-neural-narration/); // Verify default provider lookup.
}); // End host integration test.
