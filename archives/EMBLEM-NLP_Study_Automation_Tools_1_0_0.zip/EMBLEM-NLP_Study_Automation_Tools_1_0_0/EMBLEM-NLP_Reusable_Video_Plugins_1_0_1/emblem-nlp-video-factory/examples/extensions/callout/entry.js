// Trusted executable extension implementing scene API 1.0.0. Do not load unreviewed third-party code.
const esc = value => String(value).replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[x])); // Escape every supplied label.
export default { // Export the same identity declared in plugin.json.
 id: 'callout', version: '1.0.0', apiVersion: '1.0.0', // Stable extension identifiers.
 validate(scene) { if(typeof scene.data.message !== 'string' || !scene.data.message.trim() || scene.data.message.length>40) throw new Error('Callout requires a 1..40 character message'); }, // Do not shrink arbitrarily long text.
 render(ctx) { // Render from explicit project data and normalized transition time.
  const x=ctx.width*.08, y=ctx.height*.36, size=ctx.width*.037, width=ctx.width*.84; // Responsive position above caption reserve.
  return {svg:`<rect x="${x}" y="${y-60}" width="${width}" height="130" fill="${ctx.theme.surface}" stroke="${ctx.theme.accent}"/><text x="${x+20}" y="${y}" font-family="${esc(ctx.theme.bodyFont)}" font-size="${size}" fill="${ctx.theme.ink}">${esc(ctx.scene.data.message)}</text>`,text:[{text:ctx.scene.data.message,x:x+20,y:y-size,width:ctx.scene.data.message.length*size*.65,height:size*1.3,size,role:'extension-callout'}]}; // Expose layout observations to the audit adapter.
 } // This sample uses conservative bounds; production extensions should use measured glyph widths.
};
