"""Local SVG/PCM/FFmpeg backend. Source content and subjects are supplied by a project."""
from __future__ import annotations
import argparse, base64, hashlib, importlib.metadata, io, json, math, os, shutil, subprocess, sys, wave
from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone

def sha(path):
    h=hashlib.sha256() # Media identities use bounded memory.
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def save(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True) # Every output is caller-declared.
    p.with_suffix(p.suffix+'.tmp').write_text(json.dumps(data,indent=2)+'\n')
    p.with_suffix(p.suffix+'.tmp').replace(p) # Atomic manifests cannot resemble partial success.

def run(args,log=None):
    result=subprocess.run([str(a) for a in args],capture_output=True) # No shell interpolation.
    if log:Path(log).write_bytes(result.stdout+result.stderr)
    if result.returncode or (Path(str(args[0])).name in ('ffmpeg','ffprobe') and result.stderr.strip()):
        raise RuntimeError(f'{Path(str(args[0])).name} failed ({result.returncode}): '+result.stderr.decode(errors='replace')[-2000:])
    return result.stdout

def probe(file):
    return json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',file])) # Inspect encoded output, not intended metadata.

def contained(root,relative):
    if not isinstance(relative,str) or '\\' in relative or Path(relative).is_absolute() or '..' in Path(relative).parts:raise ValueError('Unsafe project asset path')
    p=(root/relative).resolve(strict=True)
    if not p.is_relative_to(root.resolve()):raise ValueError('Asset symlink escaped project')
    return p

def wave_info(file):
    with wave.open(str(file),'rb') as w:
        if w.getnchannels()!=1 or w.getsampwidth()!=2 or w.getcomptype()!='NONE':raise ValueError('Supply mono PCM16 WAV; no implicit speech conversion')
        if w.getnframes()==0:raise ValueError('Empty speech')
        return {'sampleRate':w.getframerate(),'samples':w.getnframes(),'durationSeconds':w.getnframes()/w.getframerate(),'sha256':sha(file)}

def doctor():
    result={'python':sys.version,'executables':{x:shutil.which(x) for x in ['ffmpeg','ffprobe','fc-match']},'dependencies':{},'networkInstall':False}
    for name in ['CairoSVG','Pillow','numpy','PyMuPDF']:
        try:result['dependencies'][name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:result['dependencies'][name]=None
    result['ready']=all(result['executables'].values()) and all(result['dependencies'].values()) # Voice inference has its own explicit preflight.
    return result

def font_metrics(project):
    from PIL import ImageFont # Measure local glyphs without distributing font binaries.
    chars=set(chr(i) for i in range(32,127))|set(json.dumps(project,ensure_ascii=False))
    result={}
    for role,key in [('body','bodyFont'),('display','displayFont')]:
        family=project['theme'][key]
        out=run(['fc-match','-f','%{file}\n%{family}\n',family]).decode().splitlines()
        if len(out)<2 or family.casefold() not in out[1].casefold():raise ValueError('Requested font unavailable: '+family)
        font=ImageFont.truetype(out[0],100) # A recorded actual host font, not an estimated system alias.
        result[role]={'family':family,'resolvedFamily':out[1],'sha256':sha(out[0]),'widths':{c:float(font.getlength(c)) for c in chars},'fallback':float(font.getlength('M'))}
    return result

def prepare_assets(project,root,out):
    from PIL import Image # Raster assets remain within the manifest's root.
    assets={}
    for asset in project['assets']:
        file=contained(root,asset['path'])
        if sha(file)!=asset['sha256']:raise ValueError('Changed source '+asset['id'])
        if asset['kind']=='pdf':
            import fitz # Render original page pixels; do not execute document actions.
            with fitz.open(file) as doc:
                p=asset['page']-1
                if p<0 or p>=len(doc):raise ValueError('PDF page outside document')
                page=doc[p];rect=page.rect
                if asset.get('crop'):
                    x,y,w,h=asset['crop'];rect=fitz.Rect(rect.x0+x*rect.width,rect.y0+y*rect.height,rect.x0+(x+w)*rect.width,rect.y0+(y+h)*rect.height)
                pix=page.get_pixmap(matrix=fitz.Matrix(2,2),clip=rect,alpha=False)
                image=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB')
        else:
            image=Image.open(file).convert('RGB')
            if image.width*image.height>64_000_000:raise ValueError('Source image exceeds pixel budget')
            if asset.get('crop'):
                x,y,w,h=asset['crop'];image=image.crop((round(x*image.width),round(y*image.height),round((x+w)*image.width),round((y+h)*image.height)))
        target=out/'sources'/f'{asset["id"]}.png';target.parent.mkdir(exist_ok=True);image.save(target)
        assets[asset['id']]={**asset,'width':image.width,'height':image.height,'dataUri':'data:image/png;base64,'+base64.b64encode(target.read_bytes()).decode(),'renderedSha256':sha(target)}
    return assets

def ass_time(seconds):
    n=round(seconds*100);h,n=divmod(n,360000);m,n=divmod(n,6000);s,c=divmod(n,100)
    return f'{h}:{m:02}:{s:02}.{c:02}' # Native cues are estimated phrases, not forced word alignment.

def phrase_chunks(text,width=42):
    lines=[];line=''
    for word in text.split():
        if len(word)>width:raise ValueError('Caption has an unbreakable long token; supply a checked pronunciation/display form')
        if line and len(line+' '+word)>width:lines.append(line);line=word
        else:line=(line+' '+word).strip()
    if line:lines.append(line)
    return ['\n'.join(lines[i:i+2]) for i in range(0,len(lines),2)] # At most two authored lines.

def captions(project,rows,out):
    cues=[]
    for row in rows:
        if not row.get('speech'):continue
        chunks=phrase_chunks(row['narration']['text']);weights=[len(x.split()) for x in chunks];total=sum(weights);cursor=row['speechStartSeconds']
        for text,weight in zip(chunks,weights):
            end=cursor+row['speech']['durationSeconds']*weight/total
            cues.append({'start':cursor,'end':end,'text':text,'alignment':'estimated-within-measured-utterance'});cursor=end
    if not cues:return None,[]
    def time_srt(t):
        n=round(t*1000);h,n=divmod(n,3600000);m,n=divmod(n,60000);s,ms=divmod(n,1000)
        return f'{h:02}:{m:02}:{s:02},{ms:03}'
    (out/'captions.srt').write_text('\n\n'.join(f'{i+1}\n{time_srt(c["start"])} --> {time_srt(c["end"])}\n{c["text"]}' for i,c in enumerate(cues))+'\n')
    def ass_color(s):return '&H00'+s[5:7]+s[3:5]+s[1:3]
    c=project['canvas'];theme=project['theme']
    text=f"""[Script Info]
ScriptType: v4.00+
PlayResX: {c['width']}
PlayResY: {c['height']}
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{theme['bodyFont']},{round(c['width']*.042)},{ass_color(theme['ink'])},{ass_color(theme['paper'])},{ass_color(theme['paper'])},0,0,0,0,100,100,0,0,1,0,0,2,40,40,60,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    for cue in cues:
        safe=cue['text'].replace('\\','\\\\').replace('{','\\{').replace('}','\\}').replace('\n',r'\N')
        text+=f'Dialogue: 0,{ass_time(cue["start"])},{ass_time(cue["end"])},Default,,0,0,0,,{safe}\n'
    p=out/'captions.ass';p.write_text(text)
    return str(p),cues

def prepare(project_path,output,speech_path=None):
    project_path=Path(project_path).resolve();root=project_path.parent;out=Path(output).resolve();project=json.loads(project_path.read_text())
    out.mkdir(parents=True,exist_ok=True);assets=prepare_assets(project,root,out);metrics=font_metrics(project)
    generated=json.loads(Path(speech_path).read_text())['segments'] if speech_path else []
    if len({s['id'] for s in generated})!=len(generated):raise ValueError('Duplicate generated speech segment')
    generated={s['id']:s for s in generated};fps=project['canvas']['fps'];frame=0;rows=[];rate=None
    for s in project['scenes']:
        row=dict(s);pre=s.get('preHoldSeconds',1.0);post=s.get('postHoldSeconds',2.0);speech=None;audio=None
        if project['mode']=='narrated':
            decl=s['narration'].get('audio')
            if decl:audio=contained(root,decl['path']);expected=decl['sha256']
            else:
                g=generated.get(s['id'])
                if not g or g['text']!=s['narration']['text'] or g.get('spokenText')!=(s['narration'].get('spokenText') or s['narration']['text']):raise ValueError('Missing/mismatched full narration '+s['id'])
                audio=contained(Path(speech_path).resolve().parent,g['path']);expected=g['sha256']
            speech=wave_info(audio)
            if speech['sha256']!=expected:raise ValueError('Changed narration '+s['id'])
            if rate is not None and speech['sampleRate']!=rate:raise ValueError('All scene WAVs must share a native rate; resampling must be an explicit preprocessing step')
            rate=speech['sampleRate'];duration=pre+speech['durationSeconds']+post
        else:duration=s['durationSeconds']
        count=math.ceil(duration*fps-1e-9)
        row.update({'startFrame':frame,'endFrame':frame+count,'frames':count,'durationSeconds':count/fps,'speech':speech,'audioPath':str(audio) if audio else None,'speechStartSeconds':frame/fps+pre,'postHoldSeconds':post,'preHoldSeconds':pre,'transitionFrames':round(s.get('transitionSeconds',.8)*fps)})
        rows.append(row);frame+=count
    audio_master=None
    if rate:
        audio_master=out/'narration.wav'
        with wave.open(str(audio_master),'wb') as dst:
            dst.setparams((1,2,rate,0,'NONE','not compressed'));cursor=0
            def silence(n):
                while n:
                    k=min(n,65536);dst.writeframesraw(b'\0\0'*k);n-=k
            for row in rows:
                start=round(row['speechStartSeconds']*rate);silence(start-cursor)
                with wave.open(row['audioPath'],'rb') as src:
                    while True:
                        data=src.readframes(65536)
                        if not data:break
                        dst.writeframesraw(data)
                cursor=start+row['speech']['samples'];end=round(row['endFrame']/fps*rate)
                if cursor>end:raise ValueError('Audio overruns scene boundary')
                silence(end-cursor);cursor=end
    caption_path,cues=captions(project,rows,out)
    job={'schemaVersion':'1.0.0','project':project,'projectSha256':sha(project_path),'assets':assets,'fontMetrics':metrics,'scenes':rows,'totalFrames':frame,'durationSeconds':frame/fps,'audioMaster':str(audio_master) if audio_master else None,'audioMasterSha256':sha(audio_master) if audio_master else None,'captions':cues,'captionFile':caption_path,'humanApproval':'PENDING'}
    save(out/'prepared.json',job);return {'prepared':str(out/'prepared.json'),'frames':frame,'durationSeconds':frame/fps}

def raster(output):
    import cairosvg # The native raster dependency is external and checked by doctor.
    from PIL import Image
    out=Path(output);manifest=json.loads((out/'frames.json').read_text());checked=[]
    for f in manifest['frames']:
        target=out/f['png'];target.parent.mkdir(exist_ok=True)
        cairosvg.svg2png(url=str(out/f['svg']),write_to=str(target))
        with Image.open(target) as im:rgb=im.convert('RGB');rgb.save(target) # Consistent pixel mode prevents FFmpeg filter resets.
        if f['settled']:
            import numpy as np
            a=np.asarray(rgb);y=manifest['captionBandStart'];band=a[y:]
            std=float(band.astype(float).std(axis=(0,1)).max())
            if std>.01:raise ValueError('Authored artwork entered caption band: '+f['sceneId'])
            checked.append({'sceneId':f['sceneId'],'png':f['png'],'sha256':sha(target),'captionBandStd':std})
    save(out/'layout-audit.json',{'status':'PASS','settledStates':checked,'scope':'Authored pixel geometry; not physical device caption reflow or understanding'});return {'rasterized':len(manifest['frames']),'settled':len(checked)}

def audio_correlation(source,video):
    import numpy as np # Bounded streaming correlation, not subjective voice scoring.
    with wave.open(str(source),'rb') as src:
        rate=src.getframerate();expected=src.getnframes();p=subprocess.Popen(['ffmpeg','-v','error','-i',str(video),'-map','0:a:0','-ac','1','-ar',str(rate),'-f','s16le','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        n=0;sx=sy=sxx=syy=sxy=0.;remaining=expected
        while remaining:
            k=min(65536,remaining);raw=src.readframes(k);nbytes=len(raw);data=b''
            while len(data)<nbytes:
                block=p.stdout.read(nbytes-len(data))
                if not block:break
                data+=block
            if len(data)!=nbytes:raise ValueError('Encoded narration truncated')
            x=np.frombuffer(raw,dtype='<i2').astype(float);y=np.frombuffer(data,dtype='<i2').astype(float)
            n+=len(x);sx+=x.sum();sy+=y.sum();sxx+=np.dot(x,x);syy+=np.dot(y,y);sxy+=np.dot(x,y);remaining-=len(x)
        extra=p.stdout.read();err=p.stderr.read();ret=p.wait()
        if ret or err:raise ValueError('Audio decode error')
        corr=(n*sxy-sx*sy)/math.sqrt(max((n*sxx-sx*sx)*(n*syy-sy*sy),1e-30))
        if corr<.985:raise ValueError('Encoded narration differs from generated complete PCM')
        return {'sampleRate':rate,'sourceSamples':n,'extraDecodedSamples':len(extra)//2,'fullSignalCorrelation':float(corr),'naturalnessScore':None}

def inspect(video,expected=None,audio=None):
    info=probe(video);streams=info['streams'];vs=[x for x in streams if x['codec_type']=='video'];aa=[x for x in streams if x['codec_type']=='audio'];ss=[x for x in streams if x['codec_type']=='subtitle']
    if len(vs)!=1:raise ValueError('Expected one video stream')
    if expected and int(vs[0].get('nb_frames',0))!=expected:raise ValueError('Incomplete picture frame count')
    run(['ffmpeg','-v','error','-i',video,'-map','0:v:0','-map','0:a?','-f','null','-']) # Check entire output including ending.
    result={'status':'TECHNICAL_MEDIA_PASS','sha256':sha(video),'frames':int(vs[0].get('nb_frames',0)),'width':vs[0]['width'],'height':vs[0]['height'],'fps':vs[0]['avg_frame_rate'],'durationSeconds':float(vs[0]['duration']),'audioStreams':len(aa),'subtitleStreams':len(ss),'chapterCount':len(info.get('chapters',[])),'completeDecode':'PASS','releaseApproved':False,'humanApproval':'PENDING'}
    if audio:result['audioIdentity']=audio_correlation(audio,video)
    return result

def encode(output):
    out=Path(output).resolve();job=json.loads((out/'prepared.json').read_text());fm=json.loads((out/'frames.json').read_text());project=job['project'];fps=project['canvas']['fps'];listing=['ffconcat version 1.0']
    for f in fm['frames']:listing += [f"file '{f['png']}'",f'option framerate {fps}',f"duration {f['repeatFrames']/fps:.12f}"]
    listing += [f"file '{fm['frames'][-1]['png']}'",f'option framerate {fps}'];(out/'picture.ffconcat').write_text('\n'.join(listing)+'\n')
    picture=out/'picture.mp4';target=out/'video.mp4'
    run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',out/'picture.ffconcat','-vf',f'fps={fps},setsar=1','-frames:v',job['totalFrames'],'-an','-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-threads','2','-r',fps,'-fps_mode','cfr',picture],out/'encode.log')
    actual=probe(picture)['streams'][0]
    if int(actual.get('nb_frames',0))!=job['totalFrames']:raise ValueError('Picture encoding omitted hold frames')
    meta=[';FFMETADATA1']
    for row in job['scenes']:
        title=row['title'].replace('\\','\\\\').replace('=','\\=').replace(';','\\;').replace('#','\\#').replace('\n',' ')
        meta += ['[CHAPTER]',f'TIMEBASE=1/{fps}',f'START={row["startFrame"]}',f'END={row["endFrame"]}',f'title={title}']
    (out/'chapters.ffmeta').write_text('\n'.join(meta)+'\n')
    args=['ffmpeg','-y','-v','error','-i',picture]
    if job['audioMaster']:args+=['-i',job['audioMaster'],'-i',job['captionFile'],'-i',out/'chapters.ffmeta','-map','0:v:0','-map','1:a:0','-map','2:s:0','-map_metadata','3','-map_chapters','3','-c:v','copy','-c:a','aac','-b:a','128k','-c:s','mov_text','-disposition:s:0','0','-metadata:s:s:0','language=eng','-metadata:s:s:0','handler_name=English CC / optional / estimated phrase timing']
    else:args+=['-i',out/'chapters.ffmeta','-map','0:v:0','-map_metadata','1','-map_chapters','1','-c:v','copy','-an']
    args+=['-metadata','title='+project['title'],'-metadata','comment=Generated review candidate. Synthetic voice where present; human acceptance pending.','-movflags','+faststart',target]
    run(args,out/'mux.log') # No -shortest or frame limit is allowed in the final audio mux.
    report=inspect(target,job['totalFrames'],job['audioMaster'])
    if project['mode']=='narrated' and (report['audioStreams']!=1 or report['subtitleStreams']!=1):raise ValueError('Exactly one audio and optional CC track required')
    if report['chapterCount']!=len(job['scenes']):raise ValueError('Missing chapter metadata')
    save(out/'media-audit.json',report);return report

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['doctor','prepare','raster','encode','inspect']);p.add_argument('--project');p.add_argument('--out');p.add_argument('--speech');p.add_argument('--video');a=p.parse_args()
    result=doctor() if a.command=='doctor' else prepare(a.project,a.out,a.speech) if a.command=='prepare' else raster(a.out) if a.command=='raster' else encode(a.out) if a.command=='encode' else inspect(a.video)
    print(json.dumps(result,indent=2)) # One machine-readable result goes to stdout.
if __name__=='__main__':
    try:main()
    except Exception as e:print(json.dumps({'status':'EXECUTION_BLOCKED','error':str(e)}),file=sys.stderr);sys.exit(2) # A failed build is not a deliverable.
