# EMBLEM-NLP Video Factory — 1.0.1

Run the shipped compiled CLI; no build step is needed for runtime:

```sh
node dist/cli.js doctor
node dist/cli.js plugins
node dist/cli.js plan --project examples/silent-square/project.json
node dist/cli.js render --project examples/silent-square/project.json --out /your/workspace/new-build
node dist/cli.js render --project examples/custom-extension/project.json --plugin examples/extensions/callout --out /your/workspace/custom-build
```

CLI accepts `--python`, `--voice-runtime`, `--voice-python`, `--voice-plugin`, `--speech` and repeated `--plugin`. Voice settings are trusted operator settings, never an untrusted project command. Outputs must be new directories. A failed build leaves an explicit blocked report.

API:

```js
import {validate, plan, render, frame} from './dist/factory.js';
await validate('/workspace/project.json');
const planned = await plan('/workspace/project.json');
const result = await render('/workspace/project.json', '/workspace/build-001', {
  voiceRuntime: '/workspace/runtime',
  plugins: ['/workspace/approved-extension']
});
```

`frame(preparedJob, sceneIndex, timeSeconds, options)` returns editable SVG plus text-layout observations. Prepared jobs are execution intermediates. Helpers in `dist/helpers.js` expand explicit full-reading paragraphs or each table row; they do not summarize a source or invent per-row narration.

Core system prerequisites: Node >=20; Python >=3.11; FFmpeg/FFprobe; Fontconfig; system Cairo; named host fonts; Python requirements listed in requirements.txt. Tested on Linux/Node22/Python3.13. No other platform is claimed tested. The doctor checks imports/tools, not external voice readiness.

For TypeScript development only: `npm install` then `npm run build`. Exact dev versions are declared. The runtime distribution has no npm production dependencies. `npm test` runs source contracts; `python -m unittest discover -s tests -p 'test_*.py' -v` tests media helpers. Both still require the host prerequisites described above for rendering.

Scenes have conservative bounded layouts. Long source text, excessive notes or invalid geometry trigger an error; split content into more scenes. The square and portrait examples were rendered, not merely validated. Arbitrary extreme aspect ratios and host fonts require visual review.

MCP: `node dist/mcp.js --workspace /your/workspace`. See docs/MCP_SERVER_EXAMPLE.json. Standard input/output contain newline JSON-RPC only. Supplied WAVs or explicit silent preview are supported through the current four tools; use the voice skill/CLI before calling MCP for new narration. Client installation is not automatic on ZIP upload.
