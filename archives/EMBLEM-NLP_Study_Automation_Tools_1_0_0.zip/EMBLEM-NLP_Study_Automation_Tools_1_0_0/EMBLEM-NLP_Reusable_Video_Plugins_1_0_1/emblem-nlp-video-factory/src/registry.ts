import fs from 'node:fs'; // Load only explicitly trusted extension manifests.
import path from 'node:path'; // Keep extension entries within their own package.
import {pathToFileURL} from 'node:url'; // Import compiled ES modules portably.
import type {Plugin} from './types.js'; // Stable scene interface.
import {builtins} from './plugins.js'; // Seven generic adapters ship with the core.
import {readJSON,safeAsset,sha,requireValue} from './common.js'; // Preserve code identity and containment.
export async function registry(directories:string[]=[]):Promise<Map<string,Plugin>> {const r=new Map(builtins.map(p=>[p.id,p]));for(const dir of directories){const root=fs.realpathSync(dir),m=readJSON(path.join(root,'plugin.json'));requireValue(m.apiVersion==='1.0.0'&&typeof m.entry==='string'&&/^[a-z][a-z0-9-]+$/.test(m.id),'Incompatible extension manifest');requireValue(!r.has(m.id),'Duplicate plugin id');const file=safeAsset(root,m.entry);requireValue(m.sha256&&sha(file)===m.sha256,'Extension entry hash mismatch');const mod=await import(pathToFileURL(file).href),p=mod.default;requireValue(p?.id===m.id&&p.version===m.version&&p.apiVersion===m.apiVersion&&typeof p.validate==='function'&&typeof p.render==='function','Invalid extension API');r.set(p.id,p);}return r;} // Extension JavaScript is trusted executable code, not a security sandbox.
