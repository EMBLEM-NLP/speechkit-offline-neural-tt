"""Verify the extracted immutable package's exact SHA256SUMS payload."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
try:
 expected={}
 for line in (root/'SHA256SUMS').read_text().splitlines():
  digest,rel=line.split('  ',1);p=(root/rel).resolve()
  if not p.is_relative_to(root) or not p.is_file() or (root/rel).is_symlink():raise ValueError('Unsafe/missing payload '+rel)
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  if h!=digest:raise ValueError('Hash mismatch '+rel)
  expected[rel]=digest
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and str(p.relative_to(root))!='SHA256SUMS' and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts}
 if actual!=set(expected):raise ValueError('Unexpected/missing files '+str(actual^set(expected)))
 print(json.dumps({'status':'PAYLOAD_VERIFIED','files':len(expected),'root':str(root)}))
except Exception as e:
 print(json.dumps({'status':'VERIFY_FAILED','error':str(e)}),file=sys.stderr);sys.exit(2)
