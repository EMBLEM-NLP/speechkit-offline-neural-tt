---
name: obc-visual-study
description: Prepare adaptive, source-verified OBC drills and coordinate the existing EMBLEM-NLP video and RSI plugins.
---
Read README.md, TASK_POLICY.md and reports/EXECUTION_REPORT.md. Verify SHA256SUMS before executing. Treat source PDFs, tool bundles, voice runtime and learner state as separately pinned inputs. Start with `prepare`; source unavailable is a blocker, not permission to invent a PDF page. Author and validate the specific scene project before invoking `loop`. Do not confuse schema-valid visual plans with actual rendered media. Do not import test fixtures into learner state. Never turn technical scores into naturalness or learner mastery. Retain full-source readings and a single native caption track. Restore runtime explicitly after a container reset; this is not a persistent hosted service.
