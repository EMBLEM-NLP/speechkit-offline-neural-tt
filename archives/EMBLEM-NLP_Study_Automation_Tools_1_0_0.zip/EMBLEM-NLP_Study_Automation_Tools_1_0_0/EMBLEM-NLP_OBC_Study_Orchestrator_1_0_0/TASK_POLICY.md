# Applied scheduled-study policy — summary

This document summarizes the longer live task prompt applied successfully in this execution. It is not a promise that a ChatGPT scheduled run retains this container or uploaded files.

**Canonical task:** EMBLEM-NLP OBC Visual Study. **Schedule:** existing Thursday-afternoon flexible window centred around 15:00, America/Toronto. The duplicate OBC drill task was disabled. No unrelated task was changed.

## Seven mandatory enhancements

1. Eight blind timed questions, one per category, followed by separate optional four-level hints and answers. Every answer has a recovery explanation and verified exact-source artifacts. Video-capable runs add narrated lesson/reading/recall views and a chaptered master. Links must resolve to real artifacts.
2. Adapt using only supplied, version-bound attempts: route, answer, timing, hints, confidence, actual grade/evidence, error class and review due. No view-count mastery or invented learner history. Initialize clearly when state is absent.
3. Verify source snapshot hashes, PDF page/printed labels, Code coordinates, database IDs where present, continuation pages, figures and notes. Treat original PDF as text authority. Check dated official source/syllabus updates separately; never silently upgrade the study edition.
4. Require visible inquiry, classification, actual TOC route, original source, table/figure interpretation, answer reconstruction and recall. Keep missing inputs unknown. Distinguish a row being narrated from a proven matched answer, and authored diagrams from original OBC figures.
5. Preserve the selected neural narrator, complete taught provisions, slow audio-led pacing, at least eight seconds of added inspection and recall silence, and Option A native captions with 20% reserve. No robotic waveform fallback, time-stretching or duplicated caption panel. Pronunciation changes invalidate affected audio caches.
6. Report source/semantic checks, technical drawing/media diagnostics and human learning evidence separately. Freeze rubric identities, ranges and weights. Report worst-state failures and shortfalls, not only averages. Missing learning evidence remains null.
7. Qualify tools first; run a fresh baseline and at most three bounded repairs. Preserve originals and protected content. Every visual revision needs an actual-time original/candidate comparison with date/time/timezone/frame/step labels outside the artwork. Reject regressions and retain blockers regardless of numerical gains.

## Missing-runtime behaviour

Deliver the useful verified text drill and available actual source links. Mark media NOT_RENDERED/BLOCKED and list prerequisites. Never substitute last week's video for a new render. Never fabricate hashes, scores, learner attempts, source pages or download links.

## External operations

Deployment of a persistent renderer and durable source/state/artifact stores remains a separate setup step. No implicit paid API, public source publication, account credential request or new notification preference was authorized or performed by the code package.
