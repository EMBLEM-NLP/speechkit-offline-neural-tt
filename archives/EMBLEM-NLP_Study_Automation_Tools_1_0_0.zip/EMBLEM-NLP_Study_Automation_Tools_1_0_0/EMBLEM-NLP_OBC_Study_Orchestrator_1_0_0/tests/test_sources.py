"""Synthetic source fixtures, never production OBC or learner evidence."""
import importlib.util, tempfile, json, sqlite3, unittest
from pathlib import Path
import fitz
spec=importlib.util.spec_from_file_location('bridge',Path(__file__).parents[1]/'python/source_bridge.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
class Sources(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name);self.pdf=self.root/'source.pdf';d=fitz.open();d.new_page().insert_text((72,72),'Fixture heading and source wording.');d.save(self.pdf);d.close()
  self.registry={'snapshot':'SYNTHETIC SOFTWARE FIXTURE','documents':[{'id':'v1','path':'source.pdf','volume':1,'sha256':b.sha(self.pdf)}],'records':[{'id':'r','documentId':'v1','pages':[1],'anchor':'Fixture heading','codePath':'TEST','databaseNodeId':None}]}
 def tearDown(self): self.t.cleanup()
 def test_actual_original_page_identity(self):
  r=b.verify(self.registry,self.root,self.root/'out');self.assertEqual(r['records'][0]['locationStatus'],'PDF_PAGE_AND_ANCHOR_VERIFIED')
 def test_wrong_source_hash_blocks(self):
  self.registry['documents'][0]['sha256']='0'*64
  with self.assertRaises(ValueError):b.verify(self.registry,self.root,self.root/'out')
 def test_missing_heading_blocks(self):
  self.registry['records'][0]['anchor']='NOT IN SOURCE'
  with self.assertRaises(ValueError):b.verify(self.registry,self.root,self.root/'out')
 def test_out_of_bounds_page_blocks(self):
  self.registry['records'][0]['pages']=[2]
  with self.assertRaises(ValueError):b.verify(self.registry,self.root,self.root/'out')
 def test_unverified_printed_label_is_null(self):
  self.registry['records'][0]['printedLabels']={'1':'Page 99'}
  r=b.verify(self.registry,self.root,self.root/'out');self.assertIsNone(r['records'][0]['pagesVerified'][0]['printedLabel'])
 def test_absent_database_does_not_fabricate_id(self):
  self.registry['records'][0]['databaseNodeId']='known'
  r=b.verify(self.registry,self.root,self.root/'out');self.assertIsNone(r['records'][0]['databaseNodeId'])
 def test_real_node_table_is_supported(self):
  db=self.root/'db.sqlite';c=sqlite3.connect(db);c.execute('CREATE TABLE node(id TEXT, volume INTEGER, page INTEGER)');c.execute('INSERT INTO node VALUES (?,?,?)',('known',1,1));c.commit();c.close();self.registry['databaseSha256']=b.sha(db);self.registry['records'][0]['databaseNodeId']='known'
  r=b.verify(self.registry,self.root,self.root/'out',db);self.assertEqual(r['records'][0]['databaseNodeId'],'known')
 def test_traversal_is_rejected(self):
  with self.assertRaises(ValueError):b.safe(self.root,'../secret.pdf')
if __name__=='__main__':unittest.main()
