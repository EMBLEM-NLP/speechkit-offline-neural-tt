# EMBLEM-NLP OBC Study Orchestrator 1.0.0

An executable TypeScript/Node sidecar implementing the control layer for seven weekly-study enhancements. It calls the existing **EMBLEM-NLP Reusable Video Plugins 1.0.1**; it does not rename or modify them. The actual ChatGPT task has been consolidated and updated separately. This download is **not a deployed persistent render service**.

## What is implemented

1. **Study packet:** balanced eight-question blind drill, four separately disclosed hints, answer key, answer PDFs with verified original pages, one-page artifacts, CSV/Markdown indexes and wrong-answer template.
2. **Adaptive selection:** deterministic error/due/transfer/new-content priority; version-bound, append-only logical learner ledger; idempotent imports; no inferred marks from views. The starter bank contains eight core and eight transfer prompts. More topics need source-reviewed authoring; sixteen prompts are not a complete curriculum.
3. **Source resolver:** pinned original PDF and SQLite hashes, actual page anchors, original-page pixel checks, read-only `node`/`nodes` lookup, null unknown IDs/printed labels, and identity-diff review blockers. Acquisition and legal interpretation of newly published official updates remain the coordinating task/reviewer's responsibility.
4. **Visual teaching contract:** required inquiry/classification/navigation/evidence/interpretation/recall stages; table and original-figure requirements; scene-role validation; matched-row evidence; schematic/uniform scale checks. `prepare` produces authoring contracts, not invented finished diagrams. Existing factory scene adapters perform rendering after an authored project is supplied.
5. **Narration policy:** exact and pronunciation-expanded text kept separate; token-boundary registry and voice-aware cache identity; no waveform alteration; narration required for teaching releases; eight-second inspection/recall holds; native-caption-only policy. Complete declared source readings are checked across ordered split scenes. No new speech model is bundled or substituted.
6. **Separate evaluations:** source results, actual unchanged RSI adapter diagnostics and learner evidence remain separate. Range/weight/null/contract guards reject mixed scoring systems. Human scores remain null without evidence.
7. **Bounded repair runner:** qualify → validate → plan → render → audit → permitted repair → dual review → compare. At most three repairs, shared wall-time budget, immutable candidate directories, protected non-theme data. Automatic repair is deliberately limited to verified theme-text contrast defects. Other defects stop for an authored patch, not a guessed semantic rewrite. No automatic independent release approval.

## Dependencies

Run shipped JavaScript using Node 20+; the local execution used Node 22.16.0. Python bridge needs PyMuPDF and ReportLab. Rendering uses the prerequisites documented in the unchanged three-plugin bundle: FFmpeg/FFprobe, graphics libraries and locally installed fonts. New speech requires the separate verified neural runtime, or checked provided WAVs. No silent network installation or paid speech API is enabled.

Compiled `dist/` is included. To rebuild TypeScript, provision TypeScript and `@types/node` as development dependencies, then run `npm run build`. No fonts, model weights, personal learner answers or account credentials are distributed.

## Prepare a source-verified eight-question packet

```sh
node dist/cli.js prepare \
  --sources /path/to/obc-pdfs \
  --database /path/to/obc.sqlite \
  --state state/learner.json \
  --at 2026-10-08T15:00:00-04:00 \
  --out /path/to/new-week
```

The source directory must contain the two filenames and exact hashes in `data/source-registry.json`. Different bytes block the source stage rather than silently applying old page numbers. Omitting `--sources` gives a visibly source-unverified text packet; it does not fabricate PDF artifacts. Output directories must be new. Videos are **NOT_RENDERED** by `prepare`.

## Record a supplied learner response

```sh
node dist/cli.js record --attempt response.json --state state/learner.json
```

Use `config/attempt.template.json`. Fill in the real question/version, response, timestamp, lookup time, hint level and confidence. Leave `grade: "ungraded"` until grading has a real evidence record. Example/test data are never learner records. Retain the state file in an explicitly selected persistent store; the container itself is not that store.

## Review a source change

```sh
node dist/cli.js source-diff --before old-registry.json --after proposed-registry.json --out source-diff.json
```

A changed hash means **review required**, not that the law materially changed. This command never downloads sources or replaces the exam snapshot.

## Run an actual bounded technical loop

```sh
node dist/cli.js loop \
  --project tests/fixtures/contrast-control.json \
  --tools /path/to/EMBLEM-NLP_Reusable_Video_Plugins_1_0_1 \
  --out /path/to/new-control-run
```

This supplied project is an explicitly silent **software test fixture**, not a new OBC lesson. It demonstrates a measured contrast defect and its bounded repair. The real local run produced baseline and candidate MP4s and a 15-second dual review.

For narrated OBC production, provide an authored factory-compatible project, its `--teaching-contract`, and checked WAVs or `--voice-runtime`. `validateTeachingProject` rejects missing stage bindings, abridged declared blocks, unsafe caption policy and missing teaching holds. Long or specialized content still needs properly authored scenes. The existing renderer rejects text overflow rather than truncating legal text.

## Tests

```sh
node --test tests/*.test.mjs
python -m unittest discover -s tests -p 'test_*.py' -v
```

Read `reports/EXECUTION_REPORT.md` for the actual test counts, outputs and remaining boundaries. Historical test counts from previous packages are not treated as new results.

## Deployment boundary

The canonical task is **EMBLEM-NLP OBC Visual Study**, Thursday afternoons around 15:00, America/Toronto. It now contains all seven policies and an explicit verified-text/blocked-media fallback. A durable runner, source store, learner-state store and artifact publishing endpoint are **not deployed**. No GitHub/Drive repository was selected or altered in this execution. Do not imply this ZIP alone provides unattended weekly MP4 production. Push/email notification preferences also remain account settings.
