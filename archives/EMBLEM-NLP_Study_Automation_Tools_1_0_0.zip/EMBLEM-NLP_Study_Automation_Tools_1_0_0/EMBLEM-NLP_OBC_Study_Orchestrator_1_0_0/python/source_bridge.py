"""Read-only PDF/SQLite verification and exact-page study-artifact generation."""
from __future__ import annotations
import argparse, hashlib, json, re, sqlite3
from pathlib import Path
import fitz
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from xml.sax.saxutils import escape

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def norm(s):
    return re.sub(r'\s+',' ',s).strip()

def save(p,v):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')

def safe(root,rel):
    p=(root/rel).resolve()
    if Path(rel).is_absolute() or not p.is_relative_to(root.resolve()): raise ValueError('Source path escapes root')
    return p

def verify(registry,source_root,out,db=None):
    """Page anchors and original-page identities are measured; semantic truth is not inferred."""
    root=Path(source_root); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    docs={}; records=[]
    conn=None
    if db:
        db=Path(db).resolve()
        expected=registry.get('databaseSha256')
        if not expected or sha(db)!=expected: raise ValueError('Database hash differs from pinned registry')
        conn=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True)
    for d in registry['documents']:
        p=safe(root,d['path'])
        if sha(p)!=d['sha256']: raise ValueError('SOURCE_SNAPSHOT_CHANGED: '+d['id'])
        docs[d['id']]=(d,fitz.open(p))
    for r in registry['records']:
        d,pdf=docs[r['documentId']]; pages=r['pages']
        if not pages or any(type(n)!=int or n<1 or n>len(pdf) for n in pages): raise ValueError('Invalid physical source page')
        page_texts={n:pdf[n-1].get_text() for n in pages}
        text=norm(' '.join(page_texts.values()))
        if not r.get('anchor') or norm(r['anchor']) not in text: raise ValueError('SOURCE_ANCHOR_NOT_VERIFIED: '+r['id'])
        # Page anchors identify a location; they are not a full legal-text completeness test.
        node_id=r.get('databaseNodeId'); node_status='NOT_REQUESTED'; node=None
        if node_id and conn:
            tables={t[0] for t in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            table='node' if 'node' in tables else 'nodes' if 'nodes' in tables else None
            if table is None: raise ValueError('No supported node metadata table')
            row=conn.execute(f'SELECT id, volume, page FROM {table} WHERE id = ?', (node_id,)).fetchone()
            node={'id':row[0],'volume':row[1],'page':row[2]} if row else None
            node_status='VERIFIED' if row else 'NODE_NOT_FOUND'
        elif node_id: node_status='DATABASE_UNAVAILABLE'
        extracted=[]
        for n in pages:
            label=f'Vol{d["volume"]}_PDF_{n}.pdf'; dest=out/'page_artifacts'/label
            if not dest.exists():
                dest.parent.mkdir(exist_ok=True); single=fitz.open();single.insert_pdf(pdf,from_page=n-1,to_page=n-1);single.save(dest);single.close()
            check=fitz.open(dest)
            a=pdf[n-1].get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False)
            b=check[0].get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False)
            if a.samples!=b.samples: raise ValueError('Extract changed source pixels')
            check.close()
            # Printed labels are supplied only with source-text evidence, never an offset guess.
            printed=r.get('printedLabels',{}).get(str(n)); label_ok=printed is not None and norm(printed) in norm(page_texts[n])
            extracted.append({'pdfPage':n,'printedLabel':printed if label_ok else None,'printedLabelStatus':'VERIFIED_TEXT' if label_ok else 'UNVERIFIED','artifact':'page_artifacts/'+label,'sha256':sha(dest),'sourcePagePixelSha256':hashlib.sha256(a.samples).hexdigest(),'textSha256':hashlib.sha256(page_texts[n].encode()).hexdigest()})
        records.append({**r,'sourceFilename':d['path'],'sourceSnapshot':registry['snapshot'],'sourceSha256':d['sha256'],'volume':d['volume'],'locationStatus':'PDF_PAGE_AND_ANCHOR_VERIFIED','databaseNodeId':node_id if node_status=='VERIFIED' else None,'databaseNodeStatus':node_status,'node':node,'pagesVerified':extracted,'semanticCompleteness':'INHERITED_DECLARED_SCOPE_REQUIRES_CONTENT_REVIEW'})
    for _,pdf in docs.values(): pdf.close()
    if conn: conn.close()
    report={'schemaVersion':'1.0.0','status':'SOURCE_LOCATIONS_VERIFIED','snapshot':registry['snapshot'],'records':records,'currentLawCheck':'NOT_RUN_SOURCE_SNAPSHOT_ONLY'}
    save(out/'SOURCE_VERIFICATION.json',report)
    return report

def answer_pdfs(session,verification,out):
    """Create separate question/answer covers and append all verified original pages."""
    out=Path(out); dest=out/'answer_artifacts';dest.mkdir(exist_ok=True)
    lookup={r['id']:r for r in verification['records']};styles=getSampleStyleSheet()
    styles['Title'].textColor=colors.HexColor('#0000FF')
    results=[]
    for index,item in enumerate(session['selected'],1):
        q=item['question']; records=[lookup[s] for s in q['sourceIds']]
        cover=dest/f'{index:02d}_{q["id"]}_cover.pdf'; final=dest/f'{index:02d}_{q["id"]}_answer.pdf'
        story=[Paragraph('EMBLEM-NLP / OBC Study',styles['Title']),Paragraph(escape(q['area']),styles['Heading2']),Paragraph(escape(q['prompt']),styles['BodyText']),Spacer(1,12),Paragraph('Answer',styles['Heading2']),Paragraph(escape(q['answer']),styles['BodyText']),Paragraph('How to recover the provision',styles['Heading2'])]
        for step in q['recovery']:story.append(Paragraph(escape(step),styles['BodyText']));story.append(Spacer(1,5))
        story.append(Paragraph('Exact source locations',styles['Heading2']))
        for r in records:
            pages=', '.join(str(p['pdfPage']) for p in r['pagesVerified'])
            story.append(Paragraph(escape(f'{r["codePath"]} | {r["sourceFilename"]} | Volume {r["volume"]} | physical PDF pages {pages}. Database node: {r["databaseNodeId"] or "not verified"}.'),styles['BodyText']));story.append(Spacer(1,7))
        story.append(Paragraph('Supplied 2024 study snapshot. Navigation aid; not a new current-law audit or project-compliance determination. All appended source pages are unchanged; cover wording is an authored explanation.',styles['BodyText']))
        SimpleDocTemplate(str(cover),pagesize=(612,792),leftMargin=42,rightMargin=42,topMargin=40,bottomMargin=40).build(story)
        pdf=fitz.open(cover); seen=set()
        for r in records:
            for p in r['pagesVerified']:
                if p['artifact'] in seen: continue
                original=fitz.open(out/p['artifact']);pdf.insert_pdf(original);original.close();seen.add(p['artifact'])
        pdf.save(final);pdf.close();cover.unlink()
        results.append({'questionId':q['id'],'answerPdf':str(final.relative_to(out)),'sha256':sha(final),'sourcePages':len(seen)})
    save(out/'ANSWER_ARTIFACTS.json',results)
    return results

def main():
    p=argparse.ArgumentParser();p.add_argument('--registry',required=True);p.add_argument('--source-root',required=True);p.add_argument('--out',required=True);p.add_argument('--database');p.add_argument('--session');a=p.parse_args()
    registry=json.loads(Path(a.registry).read_text());report=verify(registry,a.source_root,a.out,a.database)
    if a.session: answer_pdfs(json.loads(Path(a.session).read_text()),report,a.out)
    print(json.dumps({'status':report['status'],'records':len(report['records'])}))

if __name__=='__main__':
    try:main()
    except Exception as e:print(json.dumps({'status':'SOURCE_BLOCKED','error':str(e)}));raise SystemExit(2)
